<html>
<head>
<link rel="stylesheet" type="text/css" href="tpl/templates/Default/Default.css" />

<title>Zoe Babin</title>
</head>

<body>

<div id="ZBHeader">
	<a class="navigation" href="index.php"> Home </a>
	<a class="navigation" href="index.php"> Search </a>
  	<a class="navigation" href="index.php?module=about"> About </a>
  	<a class="navigation" href="index.php"> Inbox </a>
  	<?php echo $_SESSION['username'];
  	if($_SESSION['userID']!==NULL){?>
  		<a class="user" href="index.php?module=users&class=logout"> Logout </a>
  		<a class="user" href="index.php?module=users&class=profile"> Profile </a>
  	<?php }else{ ?>
  		<a class="user" href="index.php?module=users&class=login"> Login </a>
  	<?php } ?>
</div>


<?php 

//echo is_array($_SESSION['errors'])?"yes":"no";

if (is_array($_SESSION['errors']) && count($_SESSION['errors'])){ ?>
	<div id="error">
		<ul>
		<?php foreach ($_SESSION['errors'] as $error) { ?>
  			<li> <?php echo $error; ?> </li>
		<?php } ?>
		</ul>
	</div>
<?php } ?>

<div id="content">
    
		<div id="content-left">
			<!--{include file=$tplPathLeft}-->
		</div>

	<div id="content-right">
		<?php if(file_exists($tplPath)){	
			include($tplPath);
		}?>
	</div>

</div>

<div id="footer">
	�<?php echo date("Y");?> ZoeBabin.
</div>

</body>
</html>