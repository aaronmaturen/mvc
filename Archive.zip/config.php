<?php

//Dynamically figure out where in the filesystem we are located.
define('ZB_BASE_PATH',dirname(__FILE__));
//define('ZB_BASE_PATH','/Users/atmaturen/Sites/mvc');
//This is a DSN formatted according to PEAR DB's specifications. 
//define('ZB_DSN','mysql://root@localhost/framework');

//Path to centralized log file that can be accessed directly from our application classes.
//define('ZB_LOG_FILE','/tmp/fr.log');

//Path to Smarty install
define('SMARTY_DIR',ZB_BASE_PATH.'/includes/Presenter/Smarty/libs/');
define('SMARTY_CACHE_moduleS',0);
define('SMARTY_DEFAULT_TEMPLATE','Default');

// define our outer module template. You could, optionally, define this
//define('ZB_TEMPLATE','default');

define('ADMIN_EMAIL','atmaturen@gmail.com');
define('ADMIN_NAME','Aaron Maturen');

define('SITE_NAME','Zoe Babin');
define('SITE_URL','http://localhost/~atmaturen/mvc');

//define('SQL_TYPE','MYSQL');
define('SQL_DB_TYPE','Mysql');
define('SQL_DB_HOST','localhost');
define('SQL_DB_NAME','ivorypen_zoe');
define('SQL_DB_USER','ivorypen_zoe');
define('SQL_DB_PASSWORD','zoe');
?>
