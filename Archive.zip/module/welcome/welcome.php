<?php

include 'config.php';

class welcome extends ZB_Auth_No
{
	public function __construct()
	{
		parent::__construct();
	}

	public function __default()
	{
		
	}
      
	public function welcome()
	{
      
	}

	public function __destruct()
	{
		parent::__destruct();
	}
}

?>
