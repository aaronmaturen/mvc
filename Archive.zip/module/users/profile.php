<?php

class profile extends ZB_Auth_No
{
    public function __construct()
    {
        parent::__construct();
    }

    public function __default()
    {

		$user = array();

		if (isset ($_GET['userID'])){
			$user['userID'] = $_GET['userID'];
		} elseif ( isset($_SESSION['userID'])) {
			$user['userID'] = $_SESSION['userID'];
		} else {
			$user = -1;
		}

		if($user['userID']>=0){
			if (is_numeric ($user['userID'])){
				$this->DB->query("SELECT * FROM users WHERE userID = '".$user['userID']."'");
			} else {
				$this->DB->query("SELECT * FROM users WHERE username = '".$user['userID']."'");
			}
	    
			if($this->DB->numRows()==1){
				$results = $this->DB->singleRecord();
				
				foreach ($results as $field => $data){
					if(!is_numeric($field)){
						$user[$field] = $data;
						echo $field.": ".$data."<br />";
					}
				}
	
			} else {
				$_SESSION['errors'][] = 'User not found.';
			}
		}
	}

    public function __destruct()
    {
        parent::__destruct();
    }
}

?>