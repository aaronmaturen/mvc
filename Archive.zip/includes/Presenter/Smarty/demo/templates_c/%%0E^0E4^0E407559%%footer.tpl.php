<?php /* Smarty version 2.6.26, created on 2009-12-19 16:26:11
         compiled from footer.tpl */ ?>
</BODY>
</HTML>