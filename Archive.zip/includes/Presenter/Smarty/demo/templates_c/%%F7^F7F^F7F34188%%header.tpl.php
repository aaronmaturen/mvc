<?php /* Smarty version 2.6.26, created on 2009-12-19 16:26:11
         compiled from header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'popup_init', 'header.tpl', 3, false),)), $this); ?>
<HTML>
<HEAD>
<?php echo smarty_function_popup_init(array('src' => "/javascripts/overlib.js"), $this);?>

<TITLE><?php echo $this->_tpl_vars['title']; ?>
 - <?php echo $this->_tpl_vars['Name']; ?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">