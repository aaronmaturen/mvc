<?php

//ZB_User


class ZB_User extends ZB_Object_DB
{
	public $userID;
	public $password;
	public $email;
	public $birthday;
	public $login;
	public $state;
	public $zip;
	public $headline;
	public $description;
	public $city;
	
	
	public function __construct()
	{
		echo "User";	
		parent::__construct();
		/*if($userID == null) {
			
			if (!is_numeric($session->userID)) {
				$userID = 0;
			} else {
				$userID = $session->userID;
				$sql = "SELECT * FROM users WHERE userID=".$userID;
							  
				$result = $this->DB->query($sql);
				$this->setFrom($result);
			}
		}*/
	}

	public function __destruct()
	{
		parent::__destruct();
	}
}

?>